function [error]=primalLaplaceV9(Domain,u_exact,lap,NumEle,MaxIter)

[Node, CelltoVertix,~,~,P] = PolyMesher(Domain,NumEle,MaxIter);

[EdgesofP,Edges] = UniqueEdges(CelltoVertix);

ENrofP = EdgeNumbersP(EdgesofP,Edges);

TEMP = [Node(Edges(:,1),:),Node(Edges(:,2),:)];

EdgeLengths = sqrt((TEMP(:,1)-TEMP(:,3)).^2 + (TEMP(:,2)-TEMP(:,4)).^2);

EdgeNormals = Normals(Node,Edges);

EdgeCenters = Centers(Node,Edges);

[Alphas,OutwardNormals] = Outward(NumEle, ENrofP, EdgeNormals, EdgeCenters, P);

Vertices = Vert(CelltoVertix,Node);

barycenters = centroid(NumEle, Vertices, P);

NormEdges = NormalizedEdges(Node,Edges);

EdgeOrientation = Betas(EdgesofP,CelltoVertix);

gradh = Gradient(EdgeLengths,Edges,Node);

Mv = GMV(EdgeCenters,barycenters,OutwardNormals,EdgeLengths,ENrofP,CelltoVertix,Node);

Me = GME(EdgeOrientation,ENrofP,EdgeLengths,OutwardNormals,EdgeCenters,barycenters,NormEdges);

A = gradh'*Me*gradh;

Cell2Edge = CellEdgeArray(NumEle,Edges,ENrofP);

ExtEdges = find(mod(sum(Cell2Edge,1),2));

ExtNodes = unique(Edges(ExtEdges,:));

b = Mv * RHS(ExtNodes,u_exact,lap,Node);

A1=A;
A1(:,ExtNodes)=[];

A2 = A(:,ExtNodes);

xint = Node;
xint(ExtNodes,:)=[];
xext = Node(ExtNodes,:);

U_exact = u_exact(xint(:,1),xint(:,2));

rhs = b - A2*u_exact(xext(:,1),xext(:,2));

FinalA = A1;
FinalA(ExtNodes,:)=[];
FinalRHS = rhs;
FinalRHS(ExtNodes,:)=[];

x = FinalA\FinalRHS;

errorMv = Mv;
errorMv(ExtNodes,:) = [];
errorMv(:,ExtNodes) = [];

e_h = x-U_exact;
error = sqrt(e_h' * errorMv * e_h);

end

function [EdgesofP,Edges] = UniqueEdges(CelltoVertix)

alledges = [];
EdgesofP = cell(length(CelltoVertix),1);
for i = 1:length(CelltoVertix)
    temp = sort(horzcat(CelltoVertix{i},[CelltoVertix{i}(2:end);CelltoVertix{i}(1)]),2);
    EdgesofP{i} = temp;
    alledges = vertcat(alledges,temp);
end
Edges = unique(sort(alledges,2),'rows','stable');

end

function [ENrofP] = EdgeNumbersP(EdgesofP,Edges)

ENrofP = cell(length(EdgesofP),1);

for i = 1:length(EdgesofP)
    
    [~,ENrofP{i}] = ismember(EdgesofP{i},Edges,'rows');
    
end

end

function [EdgeNormals] = Normals(Node,Edges)

EdgeNormals = zeros(length(Edges),2); %Initialize

for i = 1:length(Edges)
    temp = [Node(Edges(i,1),:);Node(Edges(i,2),:)]; %For ease of code notation in the next part. temp being the coordinates of the start node
                                                    %in row 1 and the co-ordinates of the end node in row 2
    EdgeNormals(i,:) = [temp(1,2)-temp(2,2),temp(2,1)-temp(1,1)]; %Calculate edge normals. edge from (x1,y1) to (x2,y2) having normal (y1-y2,x2-x1)
    clear temp
end

EdgeNormals = normc(EdgeNormals')';

end

function [Alphas,OutwardNormals] = Outward(NumEle, ENrofP, EdgeNormals, EdgeCenters, P)

OutwardNormals = cell(NumEle,1);
Alphas = cell(NumEle,1);

for i = 1:NumEle
    temp = ENrofP{i};
    for j = 1:length(temp)
        if dot(EdgeNormals(temp(j),:),EdgeCenters(temp(j),:)-P(i,:))>=0  
            Alphas{i}(j,:) = 1;
            OutwardNormals{i}(j,:) = EdgeNormals(temp(j),:);
        else
            Alphas{i}(j,:) = -1;
            OutwardNormals{i}(j,:) = -EdgeNormals(temp(j),:);
        end
    end
end

end

function [EdgeCenters] = Centers(Node,Edges)

EdgeCenters = zeros(length(Edges),2); %Initialize edge centers array

for i = 1:length(EdgeCenters)
    EdgeCenters(i,:) = 0.5*(Node(Edges(i,1),:)+Node(Edges(i,2),:)); %Calculate the edge centers and store them in array
end

end

function [Vertices] = Vert(CelltoVertix,Node)

Vertices = cell(length(CelltoVertix),1); %Initialize array

for i = 1:length(CelltoVertix) 
    Vertices{i} = Node(CelltoVertix{i},:); %Vertices is the same as celltoVertix, expect that it stores the co-ordinates of the nodes, not thh node #
end

end

function [barycenters] = centroid(NumEle, Vertices, P)
barycenters = zeros(NumEle,2);
for i = 1:NumEle
    cellarea = 0;
    temp = vertcat(Vertices{i},Vertices{i}(1,:));
    for j = 1:length(temp)-1
        areaoftri = polyarea([temp(j:j+1,1);P(i,1)],[temp(j:j+1,2);P(i,2)]);
        tricentx = sum([temp(j:j+1,1);P(i,1)])/3 ;
        tricenty = sum([temp(j:j+1,2);P(i,2)])/3 ;
        barycenters(i,:) = barycenters(i,:)+areaoftri*[tricentx,tricenty];
        cellarea = cellarea + areaoftri;
    end
    barycenters(i,:) = barycenters(i,:)/cellarea;
    clear temp
end
end

function [Mv] = GMV(EdgeCenters,barycenters,OutwardNormals,EdgeLengths,ENrofP,CelltoVertix,Node)

Mv = zeros(length(Node));

for i = 1:length(ENrofP)
    
    R = zeros(length(CelltoVertix{i}),1);
    N = ones(length(CelltoVertix{i}),1);
    temp = CelltoVertix{i};
    
    for j=1:length(temp)
        
        R(j) = 0.25 * dot( EdgeCenters(ENrofP{i}(j),:) - barycenters(i,:) , OutwardNormals{i}(j,:) ) * EdgeLengths(ENrofP{i}(j));
        
    end
    
    Size = 1/length(temp);
    M0 = R*((R'*N)\R'); 
    M = M0 + Size*trace(M0)*(eye(length(temp)) - N*((N'*N)\N'));
    M = sparse(M);
    
    Assembly = zeros(length(temp),length(Node));
    
    Assembly = sparse(Assembly);
    
    for k = 1:length(temp)
        Assembly(k,temp(k)) = 1;
    end
    
    Mv = Mv + Assembly' * M * Assembly;
    
    clear temp
    
end

Mv = sparse(Mv);

end

function [gradh] = Gradient(EdgeLengths,Edges,Node)

gradh = zeros(length(Edges),length(Node));

for i = 1:length(Edges)
    
    gradh(i,Edges(i,1)) = -1/(EdgeLengths(i));
    
    gradh(i,Edges(i,2)) = 1/(EdgeLengths(i));
    
end

gradh = sparse(gradh);

end

function [Me] = GME(EdgeOrientation,ENrofP,EdgeLengths,OutwardNormals,EdgeCenters,barycenters,NormEdges)

Me = zeros(length(EdgeLengths));

for  i = 1:length(ENrofP)
    
    R = zeros(length(ENrofP{i}),2);
    N = zeros(length(ENrofP{i}),2);
    temp = ENrofP{i};
    
    for j = 1:length(temp)
        
        distVec = EdgeCenters(temp(j),:) - barycenters(i,:);
        
        R(j,:) = EdgeOrientation{i}(j)*EdgeLengths(temp(j))*[distVec(2),-distVec(1)];
        
        N(j,:) = NormEdges(temp(j),:);
        
    end
    
    Size = 1/length(temp);
    M0 = R*((R'*N)\R'); 
    M = M0 + Size*trace(M0)*(eye(length(temp)) - N*((N'*N)\N'));
    M = sparse(M);
    
    Assembly = zeros(length(temp),length(EdgeLengths));
    
    Assembly = sparse(Assembly);
    
    for k = 1:length(temp)
        Assembly(k,temp(k)) = 1;
    end
    
    Me = Me + Assembly' * M * Assembly;
    
    clear temp
    
end

end

function [NormEdges] = NormalizedEdges(Node,Edges)

NormEdges = zeros(length(Edges),2);

for i =1:length(Edges)
    
    start = Node(Edges(i,1),:);
    finish = Node(Edges(i,2),:);
    
    NormEdges(i,:) = finish-start;
    
end

NormEdges = normc(NormEdges')';

end

function [Cell2Edge] = CellEdgeArray(NumEle,Edges,ENrofP)

Cell2Edge = zeros(NumEle, length(Edges)); %Initialize matrix

for i = 1:NumEle
    temp = ENrofP{i};
    for j = 1:length(temp)
        Cell2Edge(i,temp(j)) = 1;
    end
    clear temp
end

end

function [rhs] = RHS(ExtNodes,u_exact,lap,Node)

rhs = zeros(length(Node),1);

for i = 1:length(rhs)
    rhs(i) = lap(Node(i,1),Node(i,2));
end

for j = ExtNodes
    rhs(j) = rhs(j) + u_exact(Node(i,1),Node(i,2));
end
end

function [EdgeOrientation] = Betas(EdgesofP,CelltoVertix)

EdgeOrientation = cell(length(EdgesofP),1);

for i = 1:length(EdgesofP)
    
    temp = EdgesofP{i};
    
    for j = 1:length(temp)
        
        if CelltoVertix{i}(j) == EdgesofP{i}(j,1)
            EdgeOrientation{i}(j) = 1;
        else
            EdgeOrientation{i}(j) = -1;
        end
        
    end
    
end

end