function [error] = Code_MFDV5(Domain,u_exact,lap,NumEle,MaxIter)

[Node, CelltoVertix,~,~,P] = PolyMesher(Domain,NumEle,MaxIter); %Create the Mesh

Edges = UniqueEdges(NumEle,CelltoVertix); %Determine the unique edges, stored as a nx2 matrix with start end end nodes as stored in Nodes

Cell2Edge = CellEdgeArray(NumEle,Edges,CelltoVertix); %Create the cell to edge array to determine  which edges belong to which cells

ExtEdges = find(mod(sum(Cell2Edge,1),2)); %Determine which edges are external. Use the Cell2Edge Array and find which edges are 
                                          %only part of 1 cell

EdgeCenters = Centers(Node,Edges); %Determine the edge centers

TEMP = [Node(Edges(:,1),:),Node(Edges(:,2),:)]; %Temporary array with start and end nodes of edges. TEMP(:,1) x co-ordinates of start nodes
                                                %TEMP(:,2) y co-ordinates of start nodes, TEMP(:,3) x co-ordinates of end nodes and TEMP(:,4) y
                                                %co-ordinates of end nodes.

EdgeLengths = sqrt((TEMP(:,1)-TEMP(:,3)).^2 + (TEMP(:,2)-TEMP(:,4)).^2); %Use the TEMP to calculate edge lengths

Vertices = Vert(CelltoVertix,Node); %Create a cell structure similiar to CelltoVertix, but with co-ordinates instead of node numbers

AreaofP = Area(NumEle,Vertices); %Calculate the area of the cells

EdgeNormals = Normals(Node,Edges); %Determine the normal for each edge

Alphas = Outward(NumEle, Cell2Edge, EdgeNormals, EdgeCenters, P); %Calculate the outward facing normals of all edges of all cells

barycenters = centroid(NumEle, Vertices, P);

Mf = GMM(NumEle, Vertices, Cell2Edge, EdgeNormals, Alphas, EdgeCenters, barycenters, EdgeLengths, Edges); %Create the Mf global matrix

divh = divMatrix(NumEle, Cell2Edge, Edges, Alphas, EdgeLengths, AreaofP); %Create divh matrix

Mp = sparse(diag(AreaofP)); %Create the Mp matrix

rhs = RHS(NumEle,ExtEdges,Edges,EdgeLengths,AreaofP,u_exact,lap,barycenters,EdgeCenters); %Construct righthandside of final system

A = sparse([Mf,-divh'*Mp;Mp*divh,zeros(NumEle)]); %Put together the matrix for the final system

x = A\rhs; %Solve system

uh = x(1:length(Edges)); %Seperate the solution
ph = x(length(Edges)+1:end);

U_exact = u_exact(barycenters(:,1),barycenters(:,2)); %Calculate exact solution on edge centers

e_h = ph-U_exact;
error = sqrt(e_h' * Mp * e_h)

%
% Vizualize the solution
%
clf; axis equal; axis off; hold on;
MaxNVer = max(cellfun(@numel,CelltoVertix));      %Max. num. of vertices in mesh
PadWNaN = @(E) [E(:)' NaN(1,MaxNVer-numel(E))];  %Pad cells with NaN
ElemMat = cellfun(PadWNaN,CelltoVertix,'UniformOutput',false);
ElemMat = vertcat(ElemMat{:});               %Create padded element matrix
patch('Faces',ElemMat,'Vertices',Node,'FaceColor','flat','FaceVertexCData',ph);
colorbar;
end

function [Edges] = UniqueEdges(NumEle,CelltoVertix)

Edges = [0,0];  %Initialize the Edges array. The edges will be stored in node form. If edge i spans the nodes a&b, then Edges(i,:) = [a,b]
                %Unknown number of nodes (Could potentially Initialize with twice the number of nodes, then remove null nodes)

for i = 1:NumEle
    temp = vertcat(CelltoVertix{i},CelltoVertix{i}(1)); %temp stores the nodes of cell i, taking the first node and adding it as an extra node as 
                                                        %there is an edge spanning from last node to the first node
    for j = 1:length(temp)-1
        if ~ismember([temp(j),temp(j+1)],Edges,'rows') && ~ismember([temp(j+1),temp(j)],Edges,'rows') %Check if the edge has already been added
            Edges(end+1,:) = [temp(j),temp(j+1)]; %Add the edge if not
        end
    end
    clear temp %Clear temp as not all cells have the same number of edges, and not clearing cuases loop issues
end

Edges = Edges(2:end,:); %Remvoe the initialization

end

function [Cell2Edge] = CellEdgeArray(NumEle,Edges,CelltoVertix)

Cell2Edge = zeros(NumEle, length(Edges)); %Initialize matrix

for i = 1:NumEle
    temp = [CelltoVertix{i},vertcat(CelltoVertix{i}(2:end),CelltoVertix{i}(1))]; %temp stores the edges of cell i
    for j = 1:length(Edges)
        if ismember(Edges(j,:),temp,'rows') || ismember(fliplr(Edges(j,:)),temp,'rows') %Checks whether the global edge i is a local edge in cell P
            Cell2Edge(i,j) = 1; %Sets the appropriate co-ordinate to 1 if the global edge is also a local edge
        end
    end
    clear temp
end

end

function [EdgeCenters] = Centers(Node,Edges)

EdgeCenters = zeros(length(Edges),2); %Initialize edge centers array

for i = 1:length(EdgeCenters)
    EdgeCenters(i,:) = 0.5*(Node(Edges(i,1),:)+Node(Edges(i,2),:)); %Calculate the edge centers and store them in array
end

end

function [Vertices] = Vert(CelltoVertix,Node)

Vertices = cell(length(CelltoVertix),1); %Initialize array

for i = 1:length(CelltoVertix) 
    Vertices{i} = Node(CelltoVertix{i},:); %Vertices is the same as celltoVertix, expect that it stores the co-ordinates of the nodes, not thh node #
end

end

function [AreaofP] = Area(NumEle,Vertices)

AreaofP = zeros(NumEle,1); %Initialize array

for i = 1:NumEle
    AreaofP(i) = polyarea(Vertices{i}(:,1),Vertices{i}(:,2)); %Use polyarea to calculate area of P using the nodes of P
end

end

function [EdgeNormals] = Normals(Node,Edges)

EdgeNormals = zeros(length(Edges),2); %Initialize

for i = 1:length(Edges)
    temp = [Node(Edges(i,1),:);Node(Edges(i,2),:)]; %For ease of code notation in the next part. temp being the coordinates of the start node
                                                    %in row 1 and the co-ordinates of the end node in row 2
    EdgeNormals(i,:) = [temp(1,2)-temp(2,2),temp(2,1)-temp(1,1)]; %Calculate edge normals. edge from (x1,y1) to (x2,y2) having normal (y1-y2,x2-x1)
    clear temp
end

EdgeNormals = normc(EdgeNormals')';

end

function [Alphas] = Outward(NumEle, Cell2Edge, EdgeNormals, EdgeCenters, P)

Alphas = cell(NumEle,1); %Initialize array

for i = 1:NumEle
    temp = find(Cell2Edge(i,:)); % Edges of cell i
    for j = 1:length(temp)
        if dot(EdgeNormals(temp(j),:),EdgeCenters(temp(j),:)-P(i,:))>=0 %Check if the dot product of the calculated normal of edge j, and the 
                                                                        %vector from the center of cell i to edge j is positive. If it is then 
                                                                        %the normal is already outward facing
            Alphas{i}(j) = 1;
        else
            Alphas{i}(j) = -1; %If it is not outward facing, use the normal in the opposite direction
        end
    end
end

end

function [Mf] = GMM(NumEle, Vertices, Cell2Edge, EdgeNormals, Alphas, EdgeCenters, barycenters, EdgeLengths, Edges)

Mf = sparse(zeros(length(Edges))); %Initialize matrix

for i = 1:NumEle
    R = zeros(length(Vertices{i}),2); %Initialize R, new for each cell i
    N = zeros(length(Vertices{i}),2); %Initialize N, new for each cell i
    temp = find(Cell2Edge(i,:)); % Relevant Edges
    for j = 1: length(temp)
        R(j,:) = Alphas{i}(j)*(EdgeCenters(temp(j),:) - barycenters(i,:))*EdgeLengths(temp(j)); %Calculate R and N elements
        N(j,:) = EdgeNormals(temp(j),:);
    end
    Size = 1/(length(temp)^2);
    M0 = R*((R'*N)\R'); %For ease of notation, precalculate M0
    M = M0 + Size*trace(M0)*(eye(length(temp)) - N*((N'*N)\N')); %Calculate local M
    M = sparse(M);
    
    Assembly = zeros(length(temp),length(Edges)); %Calculate the assembly matrix, has the same effect as the method you described in your mail
    
    for k = 1:length(temp)
        Assembly(k,temp(k)) = 1;
    end
    
    Assembly = sparse(Assembly);
    
    Mf = Mf + Assembly' * M * Assembly; %Add local matrix to the global matrix
    
    clear temp
end

end

function [divh] = divMatrix(NumEle, Cell2Edge, Edges, Alphas, EdgeLengths, AreaofP)

divh = (zeros(NumEle,length(Edges))); %Initialize array

for i = 1:NumEle
    temp = find(Cell2Edge(i,:)); %temp stores which global edges are a part of cell i
    for j = 1:length(temp)
        divh(i,temp(j)) = Alphas{i}(j)*EdgeLengths(temp(j))/AreaofP(i); %calculate the appropriate  elements of divh
    end
end

divh = sparse(divh);

end

function [rhs] = RHS(NumEle,ExtEdges,Edges,EdgeLengths,AreaofP,u_exact,lap,barycenters,EdgeCenters)

Gamma = zeros(length(Edges),1); %Initialize array

for i = ExtEdges
    %calculate appropriate elements
    Gamma(i) = EdgeLengths(i) * u_exact(EdgeCenters(i,1),EdgeCenters(i,2)); 
end

b = zeros(NumEle,1); %Initialize array

for i = 1:NumEle
    b(i) = AreaofP(i) * lap(barycenters(i,1),barycenters(i,2)); %Calculate b
end

rhs = vertcat(Gamma,-b); %Put them together

end

function [barycenters] = centroid(NumEle, Vertices, P)
barycenters = zeros(NumEle,2);
for i = 1:NumEle
    cellarea = 0;
    temp = vertcat(Vertices{i},Vertices{i}(1,:));
    for j = 1:length(temp)-1
        areaoftri = polyarea([temp(j:j+1,1);P(i,1)],[temp(j:j+1,2);P(i,2)]);
        tricentx = sum([temp(j:j+1,1);P(i,1)])/3 ;
        tricenty = sum([temp(j:j+1,2);P(i,2)])/3 ;
        barycenters(i,:) = barycenters(i,:)+areaoftri*[tricentx,tricenty];
        cellarea = cellarea + areaoftri;
    end
    barycenters(i,:) = barycenters(i,:)/cellarea;
    clear temp
end
end